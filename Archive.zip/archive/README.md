# Archive

This folder stores retired or superseded materials kept for reference.

Archived items:
- docs/api: superseded by docs/reference/api.
- docs/methods: superseded by docs/reference/estimators and
  docs/reference/api/diagnostics.

These items are no longer linked from the mkdocs navigation.
