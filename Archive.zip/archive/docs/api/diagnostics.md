# Diagnostics

::: crl.diagnostics

## Plotting

::: crl.diagnostics.plots
