"""Trajectory dataset contract."""

from __future__ import annotations

from crl.data.datasets import TrajectoryDataset

__all__ = ["TrajectoryDataset"]
