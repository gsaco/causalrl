"""Report objects for core interfaces."""

from __future__ import annotations

from crl.estimators.base import EstimatorReport as EstimationReport

__all__ = ["EstimationReport"]
