# Changelog

Full changelog:

https://github.com/gsaco/causalrl/blob/main/CHANGELOG.md
