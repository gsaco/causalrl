# Sample HTML report

The OPE report HTML is a standalone export designed to be shared outside the
Docs site. To keep the docs visually consistent, the report is embedded below.

Raw HTML file (for sharing/archival): `docs/assets/reports/intro_bandit_report.html`.

<iframe class="crl-report-frame" src="../assets/reports/intro_bandit_report.html" title="Sample OPE report"></iframe>
