# Benchmark Runner Tutorial

Benchmark harness command:

```bash
python experiments/run_benchmarks.py --output-dir results
```

Outputs:
- `results/benchmark_results.csv`
- `results/benchmark_results.jsonl`
