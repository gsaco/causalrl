# Bandit OPE Tutorial

Quickstart bandit OPE example.

```bash
python examples/quickstart/bandit_ope.py
```

Creates a synthetic bandit dataset, defines a policy value estimand, and runs
IS and WIS with diagnostics.
