# MDP OPE Tutorial

Quickstart finite-horizon MDP OPE example.

```bash
python examples/quickstart/mdp_ope.py
```

Generates trajectories, declares assumptions, and compares IS, WIS, PDIS, DR,
and FQE against the ground truth.
