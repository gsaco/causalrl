# Long-Horizon MIS vs IS

MIS replaces trajectory-level importance weights with marginalized ratios to
reduce variance in long horizons.

## Notebook

- [06_long_horizon_mis_vs_is.ipynb](https://github.com/gsaco/causalrl/blob/v4/notebooks/06_long_horizon_mis_vs_is.ipynb)
